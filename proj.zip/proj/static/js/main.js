window.oncontextmenu = function() {
    return false;
}

document.addEventListener('DOMContentLoaded', function() {
    var calendarEl = document.getElementById('calendar');
    var todoItems = [];
    var selectedDate = null;
    var check = false; 
    var calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        selectable: true,
        displayEventTime: false,
        editable: true,
        droppable: true,
        dayMaxEvents: true,
        headerToolbar: {
            left: 'prev,next today',
            center: 'title',
            right: 'addEventButton dayGridMonth,dayGridWeek,listWeek'
        },
        customButtons: {
            addEventButton: {
                text: "일정 추가",
                click: function() {
                    openModal();
                }
            }
        },
        eventClick: function(info) {
            var result = confirm("일정을 삭제하시겠습니까?");
            if (result){
                info.event.remove();
                alert("일정이 삭제되었습니다.");
                // Remove from to-do list
                removeToDoItem(info.event);
            }
        },
        dateClick: function(info) {
            selectedDate = info.dateStr;
            showToDoForDate(selectedDate);
        }
    });

    calendar.render();

    function openModal() {
        document.getElementById("myModal").style.display = "block";
    }

    function closeModal() {
        document.getElementById("myModal").style.display = "none";
    }

    var spans = document.getElementsByClassName("close");
    for (let span of spans) {
        span.onclick = function() {
            closeModal();
        }
    }

    window.onclick = function(event) {
        if (event.target == document.getElementById("myModal")) {
            closeModal();
        }
    }

    // Color selection logic
    document.querySelectorAll('.color-selection div').forEach(function(div) {
        div.addEventListener('click', function() {
            const parent = this.parentElement;
            parent.querySelectorAll('.selected').forEach(el => el.classList.remove('selected'));
            this.classList.add('selected');
        });
    });

    // Handle adding events from the modal
    document.getElementById("save-event").addEventListener("click", function() {
        var title = document.getElementById("title").value;
        var startDate = document.getElementById("start-date").value || selectedDate;
        var startTime = document.getElementById("start-time").value;
        var endDate = document.getElementById("end-date").value;
        var endTime = document.getElementById("end-time").value;
        var selectedBgColor = document.querySelector('#background-color .selected');
        var selectedTextColor = document.querySelector('#text-color .selected');
        
        var backgroundColor = selectedBgColor ? selectedBgColor.style.backgroundColor : '#3788d8';
        var textColor = selectedTextColor ? selectedTextColor.style.backgroundColor : '#ffffff';

        if (title && startDate) {
            var event = {
                title: title,
                start: startDate + 'T' + (startTime || '00:00'),
                end: endDate ? endDate + 'T' + (endTime || '23:59') : null,
                allDay: !startTime && !endTime,
                backgroundColor: backgroundColor,
                textColor: textColor
            };
            check = true;
            calendar.addEvent(event);
            addToDoItem(title, startDate, endDate);
            alert('일정이 추가되었습니다.');
            closeModal();
        } else {
            alert("제목과 시작 날짜를 입력해주세요.");
        }
    });

    // To-do List functionality
    document.getElementById("add-todo").addEventListener("click", function() {
        var todoInput = document.getElementById("new-todo");
        var todoText = todoInput.value.trim();
        if (todoText && selectedDate) {
            addToDoItem(todoText, selectedDate, selectedDate);
            todoInput.value = ""; // Clear the input
        } else {
            alert("할 일을 추가할 날짜를 선택하고 할 일을 입력해주세요.");
        }
    });

    function addToDoItem(text, startDate, endDate) {
        var todoList = document.getElementById("todo-list");
        var todoItem = document.createElement("div");
        todoItem.className = "todo-item";
        todoItem.innerHTML = `
            <input type="checkbox"/>
            <label>${text}</label>
            <button class="delete-todo">Delete</button>
        `;
        todoList.appendChild(todoItem);

        // Save to to-do items array
        todoItems.push({ text: text, startDate: startDate, endDate: endDate });

        // Delete to-do item
        todoItem.querySelector(".delete-todo").addEventListener("click", function() {
            todoList.removeChild(todoItem);
            // Optionally remove the corresponding event from the calendar
            var event = calendar.getEvents().find(event => event.title === text && event.startStr.startsWith(startDate));
            if (event) {
                event.remove();
            }
            // Remove from to-do items array
            todoItems = todoItems.filter(item => !(item.text === text && item.startDate === startDate && item.endDate === endDate));
        });
        if (check) { 
            check = false;
            return;
        }
        // Add the to-do item to the calendar as an event
        calendar.addEvent({
            title: text,
            start: startDate,
            end: endDate,
            allDay: true
        });
    }

    function showToDoForDate(dateStr) {
        var todoList = document.getElementById("todo-list");
        todoList.innerHTML = ''; // Clear the list

        var itemsForDate = todoItems.filter(item => {
            var startDate = new Date(item.startDate);
            var endDate = item.endDate ? new Date(item.endDate) : startDate;
            var selectedDate = new Date(dateStr);

            return selectedDate >= startDate && selectedDate <= endDate;
        });

        itemsForDate.forEach(item => {
            var todoItem = document.createElement("div");
            todoItem.className = "todo-item";
            todoItem.innerHTML = `
                <input type="checkbox"/>
                <label>${item.text}</label>
                <button class="delete-todo">Delete</button>
            `;
            todoList.appendChild(todoItem);

            // Delete to-do item
            todoItem.querySelector(".delete-todo").addEventListener("click", function() {
                todoList.removeChild(todoItem);
                // Optionally remove the corresponding event from the calendar
                var event = calendar.getEvents().find(event => event.title === item.text && event.startStr.startsWith(item.startDate));
                if (event) {
                    event.remove();
                }
                // Remove from to-do items array
                todoItems = todoItems.filter(todoItem => !(todoItem.text === item.text && todoItem.startDate === item.startDate && todoItem.endDate === item.endDate));
            });
        });
    }

    function removeToDoItem(event) {
        todoItems = todoItems.filter(item => !(item.text === event.title && item.startDate === event.startStr.split('T')[0] && (!item.endDate || item.endDate === event.endStr.split('T')[0])));
        showToDoForDate(event.startStr.split('T')[0]);
    }
});
