from flask import Flask, request, jsonify, render_template
from pymongo import MongoClient
from bson.json_util import dumps

app = Flask(__name__)

# MongoDB 설정
client = MongoClient('mongodb://localhost:27017/')
db = client['your_database_name']
collection = db['your_collection_name']

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/add_event', methods=['POST'])
def add_event():
    data = request.json
    collection.insert_one(data)
    return jsonify({'status': 'Event added'})

@app.route('/get_events', methods=['GET'])
def get_events():
    events = collection.find()
    return dumps(events)

@app.route('/delete_event', methods=['POST'])
def delete_event():
    data = request.json
    collection.delete_one({'_id': data['_id']})
    return jsonify({'status': 'Event deleted'})

if __name__ == '__main__':
    app.run(debug=True)
